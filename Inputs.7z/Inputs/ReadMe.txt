The P Text file is the precipitaion data in cm/hr for one year with 1 hour duration time. The ET text file is the ET data for three land covers ( Deciduous, Micelincouse, and bare (no vegetaion) )land covers in (cm/hr) withe 1 hour duration time
				
P	t		ET	
(cm/hr)	(hr)	Deci.	Misc	Bare
0.5	0	0.016	0.012	0.019
0.5	1	0.016	0.012	0.019
0.5	2	0.016	0.012	0.019
0.5	3	0.016	0.012	0.019
0.5	4	0.016	0.012	0.019
0.5	5	0.016	0.012	0.019
0.5	6	0.016	0.012	0.019
0.5	7	0.016	0.012	0.019
0	8	0.016	0.012	0.019
0	9	0.016	0.012	0.019
0	10	0.016	0.012	0.019
0.5	11	0.016	0.012	0.019
0.5	12	0.016	0.012	0.019
0.5	13	0.016	0.012	0.019
0.5	14	0.016	0.012	0.019
0.5	15	0.016	0.012	0.019
0.5	16	0.016	0.012	0.019
0	17	0.016	0.012	0.019
0	20	0.016	0.012	0.019
-	-	-	-	-
-	-	-	-	-
0	552	0.016	0.012	0.019
0	576	0.016	0.012	0.019

